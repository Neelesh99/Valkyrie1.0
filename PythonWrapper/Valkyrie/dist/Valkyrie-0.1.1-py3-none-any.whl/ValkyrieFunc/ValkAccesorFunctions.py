import os
def runValkyrie(path):
    os.system(path)