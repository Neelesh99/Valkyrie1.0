import os
def runValkyrie():
    os.system("Valk\\Valkyrie2.0.exe")